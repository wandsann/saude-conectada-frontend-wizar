import asyncio
import logging
import aiohttp
import json
import os
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
import redis
from config import *

# Configurar logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Conexão com Redis
redis_client = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, decode_responses=True)

class AIBot:
    def __init__(self, model_config):
        self.name = model_config['name']
        self.type = model_config['type']
        if self.type == 'local':
            self.url = model_config['url']
        else:
            self.api_key = model_config['api_key']

    async def generate_response(self, prompt, context=""):
        try:
            if self.type == 'local' and self.name == 'llama2':
                return await self._generate_ollama_response(prompt, context)
            elif self.name == 'deepseek-chat':
                return await self._generate_deepseek_response(prompt, context)
            elif self.name == 'microsoft/phi-2':
                return await self._generate_huggingface_response(prompt, context)
            elif self.name == 'openrouter':
                return await self._generate_openrouter_response(prompt, context)
        except Exception as e:
            logger.error(f"Erro ao gerar resposta com {self.name}: {str(e)}")
            return f"Desculpe, ocorreu um erro ao processar sua mensagem com {self.name}."
        
    async def _generate_ollama_response(self, prompt, context):
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.url}/api/generate",
                json={
                    "model": "llama2",
                    "prompt": f"{context}\nUser: {prompt}\nAssistant:",
                    "stream": False
                }
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get('response', '')
                else:
                    raise Exception(f"Erro na API Ollama: {response.status}")

    async def _generate_deepseek_response(self, prompt, context):
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(
                "https://api.deepseek.com/v1/chat/completions",
                headers=headers,
                json={
                    "model": "deepseek-chat",
                    "messages": [
                        {"role": "system", "content": context},
                        {"role": "user", "content": prompt}
                    ]
                }
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return data['choices'][0]['message']['content']
                else:
                    raise Exception(f"Erro na API DeepSeek: {response.status}")

    async def _generate_huggingface_response(self, prompt, context):
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(
                "https://api-inference.huggingface.co/models/microsoft/phi-2",
                headers=headers,
                json={"inputs": f"{context}\nUser: {prompt}\nAssistant:"}
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return data[0]['generated_text']
                else:
                    raise Exception(f"Erro na API HuggingFace: {response.status}")

    async def _generate_openrouter_response(self, prompt, context):
        headers = {
            "Authorization": f"Bearer {os.getenv('OPENROUTER_API_KEY')}",
            "HTTP-Referer": "https://github.com/wandsanbot",
            "X-Title": "WandsanBot"
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(
                "https://openrouter.ai/api/v1/chat/completions",
                headers=headers,
                json={
                    "model": "anthropic/claude-2",
                    "messages": [
                        {"role": "system", "content": context},
                        {"role": "user", "content": prompt}
                    ]
                }
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return data['choices'][0]['message']['content']
                else:
                    raise Exception(f"Erro na API OpenRouter: {response.status}")

# Atualizar configuração dos modelos
MODELS = {
    'ollama': {
        'name': 'llama2',
        'url': OLLAMA_URL,
        'type': 'local'
    },
    'deepseek': {
        'name': 'deepseek-chat',
        'api_key': os.getenv('DEEPSEEK_API_KEY'),
        'type': 'cloud'
    },
    'huggingface': {
        'name': 'microsoft/phi-2',
        'api_key': os.getenv('HUGGINGFACE_API_KEY'),
        'type': 'cloud'
    },
    'openrouter': {
        'name': 'openrouter',
        'api_key': os.getenv('OPENROUTER_API_KEY'),
        'type': 'cloud'
    }
}

# Criar instâncias dos bots
bots = {
    model_name: AIBot(config) 
    for model_name, config in MODELS.items()
}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /start."""
    welcome_message = (
        f"👋 Olá! Eu sou o {os.getenv('BOT_NAME', 'WandsanBot')}! Posso conversar usando diferentes modelos:\n\n"
        "🤖 /ollama - Usar modelo local Llama2\n"
        "🌐 /deepseek - Usar DeepSeek Chat\n"
        "🤗 /huggingface - Usar Microsoft Phi-2\n"
        "🔄 /openrouter - Usar OpenRouter (Claude-2)\n\n"
        "Escolha um modelo para começar!"
    )
    await update.message.reply_text(welcome_message)

async def set_model(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Define qual modelo será usado."""
    model = context.args[0] if context.args else update.message.text[1:]  # Remove '/'
    if model in bots:
        redis_client.set(f"user_model:{update.effective_user.id}", model)
        await update.message.reply_text(f"Modelo alterado para {model}! Pode começar a conversar.")
    else:
        await update.message.reply_text("Modelo não encontrado. Use /start para ver os modelos disponíveis.")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Processa mensagens do usuário."""
    user_id = update.effective_user.id
    model_name = redis_client.get(f"user_model:{user_id}")
    
    if not model_name:
        await update.message.reply_text("Por favor, escolha um modelo primeiro usando /start")
        return

    bot = bots[model_name]
    user_message = update.message.text
    chat_context = redis_client.get(f"context:{user_id}") or ""

    try:
        response = await bot.generate_response(user_message, chat_context)
        
        # Atualizar contexto
        new_context = f"{chat_context}\nUser: {user_message}\nAssistant: {response}"
        if len(new_context) > MAX_CONTEXT_LENGTH:
            new_context = new_context[-MAX_CONTEXT_LENGTH:]
        redis_client.setex(f"context:{user_id}", CONTEXT_EXPIRY, new_context)
        
        await update.message.reply_text(response)
    except Exception as e:
        logger.error(f"Erro ao gerar resposta: {e}")
        await update.message.reply_text("Desculpe, ocorreu um erro ao processar sua mensagem.")

def main():
    """Função principal."""
    application = Application.builder().token(TELEGRAM_TOKEN).build()

    # Adicionar handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("ollama", set_model))
    application.add_handler(CommandHandler("deepseek", set_model))
    application.add_handler(CommandHandler("huggingface", set_model))
    application.add_handler(CommandHandler("openrouter", set_model))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # Iniciar o bot
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main() 